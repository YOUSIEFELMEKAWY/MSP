import 'package:flutter/material.dart';
import 'package:msp1/secondScreen.dart';

void main() {
  runApp(MyApp());
}

// ignore: must_be_immutable
class MyApp extends StatelessWidget {
  MyApp({super.key});
  List<String> Names = [
    "مجله السياسه",
    "مجله التكنولوجيا",
    "مجله الرياضه",
    "مجله العلوم",
    "مجله السياسه",
    "مجله التكنولوجيا",
    "مجله الرياضه",
    "مجله العلوم",
  ];
  List<String> Images = [
    "assets/business.jpg",
    "assets/technology.jpeg",
    "assets/sports.jpg",
    "assets/science.avif",
    "assets/business.jpg",
    "assets/technology.jpeg",
    "assets/sports.jpg",
    "assets/science.avif"
  ];
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        body: SafeArea(
          child: CustomScrollView(
            scrollDirection: Axis.vertical,
            physics: const BouncingScrollPhysics(),
            slivers: [
              SliverToBoxAdapter(
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    Container(
                      width: 200,
                      color: Colors.purple,
                      child: TextButton(
                        onPressed: () {},
                        child: const Text(
                          "الاخبار",
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                    const SizedBox(
                      width: 1,
                    ),
                    Container(
                      width: 200,
                      color: Colors.purple,
                      child: TextButton(
                        onPressed: () {},
                        child: const Text(
                          "المجالات",
                          style: TextStyle(color: Colors.white),
                        ),
                      ),
                    ),
                  ],
                ),
              ),
              SliverGrid.builder(
                itemCount: Names.length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 2, crossAxisSpacing: 8, mainAxisSpacing: 8),
                itemBuilder: (context, index) {
                  return Stack(
                    alignment: Alignment.bottomRight,
                    children: [
                      Image(
                        image: AssetImage(Images[index]),
                        height: 150,
                        width: 200,
                        fit: BoxFit.cover,
                      ),
                      Padding(
                        padding: const EdgeInsets.all(4.0),
                        child: Container(
                          width: 100,
                          color: Colors.purple.withOpacity(.7),
                          child: Text(
                            Names[index],
                            textAlign: TextAlign.center,
                            style: const TextStyle(color: Colors.white),
                          ),
                        ),
                      )
                    ],
                  );
                },
              ),
              SliverToBoxAdapter(
                child: Builder(
                  builder: (context) => ElevatedButton(
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (context) => const secondScreen(),
                        ),
                      );
                    },
                    child: const Text("Next Page"),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
