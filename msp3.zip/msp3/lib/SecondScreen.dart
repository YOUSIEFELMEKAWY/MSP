// ignore: file_names
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class SecondScreen extends StatefulWidget {
  const SecondScreen({super.key, required this.t1, required this.t2});

  final TextEditingController t1;
  final TextEditingController t2;

  @override
  State<SecondScreen> createState() => _MyWidgetState();
}

class _MyWidgetState extends State<SecondScreen> {
  // ignore: non_constant_identifier_names
  int Number = 0;
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 95, 95, 95),
        foregroundColor: Colors.black,
        title: const Text(
          "CounterApp",
        ),
        elevation: 0,
      ),
      body: Center(
        child: Column(
          children: [
            const Spacer(
              flex: 1,
            ),
            Text("Your User Name is : ${widget.t1.text}"),
            Text("Your Email is :  ${widget.t2.text}"),
            const Spacer(
              flex: 1,
            ),
            Text(
              "$Number",
              style: const TextStyle(fontSize: 150),
            ),
            const Spacer(
              flex: 2,
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      Number--;
                    });
                  },
                  style: ButtonStyle(
                    minimumSize: MaterialStateProperty.all(const Size(60, 60)),
                    shape: MaterialStateProperty.all<OutlinedBorder>(
                        const CircleBorder()),
                    backgroundColor:
                        MaterialStateProperty.all<Color>(Colors.grey),
                  ),
                  child: const Text(
                    "-",
                    style: TextStyle(fontSize: 30),
                  ),
                ),
                ElevatedButton(
                  onPressed: () {
                    setState(() {
                      Number++;
                    });
                  },
                  style: ButtonStyle(
                    minimumSize: MaterialStateProperty.all(const Size(60, 60)),
                    shape: MaterialStateProperty.all<OutlinedBorder>(
                        const CircleBorder()),
                    backgroundColor:
                        MaterialStateProperty.all<Color>(Colors.grey),
                  ),
                  child: const Text(
                    "+",
                    style: TextStyle(fontSize: 30),
                  ),
                ),
              ],
            ),
            const Spacer(
              flex: 5,
            ),
          ],
        ),
      ),
    );
  }
}
