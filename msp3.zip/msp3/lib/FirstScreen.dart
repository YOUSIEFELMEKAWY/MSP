import 'package:flutter/material.dart';
import 'package:msp3/TextFieldWidget.dart';

// ignore: must_be_immutable
class FirstScreen extends StatelessWidget {
  FirstScreen({super.key, required this.textField1, required this.textField2});
  TextEditingController textField1 = TextEditingController();
  TextEditingController textField2 = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color.fromARGB(255, 95, 95, 95),
        foregroundColor: Colors.black,
        title: const Text(
          "Login",
        ),
      ),
      body: SingleChildScrollView(
        child: Column(children: [
          const ColorFiltered(
              colorFilter: ColorFilter.mode(
                Colors
                    .black, // Change this to adjust the color (black in this case)
                BlendMode.saturation,
              ),
              child: Image(image: AssetImage("assets/page1.png"))),
          const SizedBox(
            height: 10,
          ),
          TextFieldWidget(
            label: "User Name",
            tit: TextInputType.name,
            tec: textField1,
          ),
          const SizedBox(
            height: 20,
          ),
          TextFieldWidget(
            label: "email",
            tit: TextInputType.emailAddress,
            tec: textField2,
          ),
          const SizedBox(
            height: 20,
          ),
          Center(
            child: ElevatedButton(
              style: ButtonStyle(
                backgroundColor: MaterialStateProperty.all<Color>(Colors.grey),
              ),
              onPressed: () {
                Navigator.pushNamed(context, 'Second');
              },
              child: const Text(
                "Login",
                style: TextStyle(color: Colors.black),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
