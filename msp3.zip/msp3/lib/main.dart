import 'package:flutter/material.dart';
import 'package:msp3/FirstScreen.dart';
import 'package:msp3/SecondScreen.dart';

void main() {
  runApp(MyApp());
}

// ignore: must_be_immutable
class MyApp extends StatelessWidget {
  MyApp({super.key});
  TextEditingController textField1 = TextEditingController();
  TextEditingController textField2 = TextEditingController();
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      routes: {
        'Second': (context) => SecondScreen(t1: textField1, t2: textField2),
      },
      debugShowCheckedModeBanner: false,
      home: FirstScreen(textField1: textField1, textField2: textField2),
    );
  }
}
