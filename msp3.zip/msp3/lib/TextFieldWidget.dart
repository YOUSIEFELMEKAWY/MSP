import 'package:flutter/material.dart';

// ignore: must_be_immutable
class TextFieldWidget extends StatelessWidget {
  TextFieldWidget({
    super.key,
    required this.label,
    required this.tit,
    required this.tec,
  });
  final String label;
  final TextInputType tit;
  TextEditingController tec = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: tec,
      keyboardType: tit,
      decoration: InputDecoration(
        border: const OutlineInputBorder(),
        label: Text(label),
      ),
    );
  }
}
