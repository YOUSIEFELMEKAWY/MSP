package com.example.msp3

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
